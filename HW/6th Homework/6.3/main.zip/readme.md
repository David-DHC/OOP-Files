1. 设计架构：

	1. player中统一调用audio、video类，不调用MP3、wav等具体格式的类。

	2. video、audio需要实现多态，因此应用纯虚函数。

		```mermaid
		graph LR
		player-->add
		add-->video版本
		add-->audio版本
		player-->play
		player-->pause
		player-->doubleSpeed
		play-->函数中同时包括audio和video的版本
		pause-->函数中同时包括audio和video的版本
		doubleSpeed-->函数中同时包括audio和video的版本
		audio-->player
		video-->player
		mp4-->video
		A[...]-->video
		wav-->audio
		B[...]-->audio
		```

2. 设计思路：
	1. 保留给定的Audio代码，仿照其补全Video代码，包括videoList和add、play、pause。
	2. 对video使用统一接口（这仍然是仿照audio的操作）。
	3. ==double speed==功能未在头文件中包括，故在player中实现之。